# app.py

# --- PENTING: Import driver mysql.connector ---
import mysql.connector 

from flask import Flask, render_template, redirect, url_for, request, flash
from flask_login import login_user, logout_user, current_user, login_required
from config import Config
import pandas as pd
import numpy as np

# IMPORT EKSTENSI DAN MODEL DARI models.py (Factory Pattern Fix)
from models import db, login_manager, User, Criterion, Alternative, Score, VotingSession, VotingOption

import random
import json
import uuid 

# --- KONSTANTA ---
# Bobot ROC Tetap (Maksimal 10)
FIXED_ROC_WEIGHTS = [
    0.456667, 0.256667, 0.156667, 0.09, 0.04, 
    0.02, 0.015, 0.01, 0.005, 0.001
]

# DAFTAR KRITERIA UMUM UNTUK DROPDOWN
COMMON_CRITERIA = [
    "Keamanan Transaksi", 
    "Kelengkapan Produk", 
    "Kemudahan Penggunaan", 
    "Biaya Pengiriman & Promo", 
    "Kecepatan Layanan Pelanggan",
    "Kualitas Layanan",
    "Harga Produk",
    "Promosi dan Diskon",
    "Variasi Pembayaran",
    "Garansi Produk & Retur"
]
# -----------------

def create_app(config_class=Config):
    app = Flask(__name__)
    app.config.from_object(config_class)

    # 1. BINDING EKSTENSI KE APLIKASI
    db.init_app(app) 
    login_manager.init_app(app) 
    login_manager.login_view = 'login'
    login_manager.login_message_category = 'info'
    
    # 2. INI HANYA PERLU SEKALI, SETELAH SEMUA TERBINDING
    with app.app_context():
        try:
            db.create_all()
            print("Database berhasil diinisialisasi.")
        except Exception as e:
            print(f"Gagal koneksi atau inisialisasi database: {e}")
            
    # --- Fungsi untuk Menghapus Data SPK User ---
    def clear_user_data(user_id):
        """Menghapus semua Kriteria, Alternatif, dan Skor milik user tertentu."""
        try:
            # 1. Hapus SKOR terkait alternatif user
            alt_ids = [alt.id for alt in Alternative.query.filter_by(user_id=user_id).all()]
            if alt_ids:
                Score.query.filter(Score.alternative_id.in_(alt_ids)).delete(synchronize_session=False)

            # 2. Hapus ALTERNATIF
            Alternative.query.filter_by(user_id=user_id).delete(synchronize_session=False)
            
            # 3. Hapus KRITERIA
            Criterion.query.filter_by(user_id=user_id).delete(synchronize_session=False)

            db.session.commit()
            return True
        except Exception as e:
            db.session.rollback()
            print(f"Error saat menghapus data user {user_id}: {e}")
            return False

    # --- Fungsi Perhitungan ROC SPK ---
    def calculate_spk_roc(user_id, rank_input):
        selected_c_names = list(rank_input.keys())
        fixed_weights_to_use = FIXED_ROC_WEIGHTS[:len(selected_c_names)]

        alternatives = Alternative.query.filter_by(user_id=user_id).all()
        if not alternatives: 
            return None, "Tidak ada alternatif yang diinput untuk dihitung."
        
        X = {}
        for alt in alternatives:
            selected_c_ids = [Criterion.query.filter_by(user_id=user_id, name=name).first().id for name in selected_c_names]
            scores = Score.query.filter(Score.alternative_id==alt.id, Score.criterion_id.in_(selected_c_ids)).all()
            
            scores_dict = {
                db.session.get(Criterion, s.criterion_id).name: s.score_value
                for s in scores
            }
            alt_scores = []
            for name in selected_c_names:
                score = scores_dict.get(name, 0)
                alt_scores.append(score if score > 0 else np.nan) 
                
            X[alt.name] = alt_scores

        df_X = pd.DataFrame.from_dict(X, orient='index', columns=selected_c_names)
        df_X.dropna(inplace=True)

        if df_X.empty:
            return None, "Tidak ada alternatif dengan skor lengkap untuk kriteria yang dipilih."

        R = df_X.copy()
        for col in df_X.columns:
            min_val = df_X[col].min()
            max_val = df_X[col].max()
            if max_val - min_val == 0:
                R[col] = 0.0
            else:
                R[col] = (df_X[col] - min_val) / (max_val - min_val)
                
        sorted_rank_keys = sorted(rank_input, key=rank_input.get) 
        W_final = {}
        for i, crit_name_from_input in enumerate(sorted_rank_keys):
            if i < len(fixed_weights_to_use):
                W_final[crit_name_from_input] = fixed_weights_to_use[i]
            else:
                W_final[crit_name_from_input] = 0.0 
                
        W = pd.Series(W_final)
        df_W = pd.DataFrame([W], columns=R.columns)
        V = R.mul(df_W.iloc[0]).sum(axis=1)
        V = V.sort_values(ascending=False).rename("Nilai_Akhir")
        
        return V, None

    # --- Rute Landing Page ---
    @app.route('/')
    def landing():
        if current_user.is_authenticated:
            return redirect(url_for('index'))
        return render_template('venue/landing.html')

    # --- Rute Dashboard (Dashboard SPK Utama) ---
    @app.route('/dashboard')
    @login_required
    def index():
        criteria = Criterion.query.filter_by(user_id=current_user.id).order_by(Criterion.id).all()
        if not criteria:
            flash("Anda harus mengatur kriteria (Langkah 1) sebelum melanjutkan.", 'info')
            return redirect(url_for('setup_criteria'))

        alternatives = Alternative.query.filter_by(user_id=current_user.id).all()
        data_table = []
        for alt in alternatives:
            row = {'Alternatif': alt.name, 'id': alt.id}
            for crit in criteria:
                score = Score.query.filter_by(alternative_id=alt.id, criterion_id=crit.id).first()
                row[crit.name] = score.score_value if score and score.score_value > 0 else '0'
            data_table.append(row)
            
        available_ranks = list(range(1, len(criteria) + 1))
        return render_template('index.html', criteria=criteria, alternatives=alternatives, 
                               data_table=data_table, available_ranks=available_ranks)

    # --- Rute Reset Data ---
    @app.route('/reset_data')
    @login_required
    def reset_data():
        if clear_user_data(current_user.id):
            flash('Semua data Anda telah berhasil dihapus.', 'success')
            return redirect(url_for('setup_criteria'))
        else:
            flash('Gagal menghapus data.', 'danger')
            return redirect(url_for('index'))

    # --- Rute Setup Kriteria ---
    @app.route('/setup', methods=['GET', 'POST'])
    @login_required
    def setup_criteria():
        existing_criteria = Criterion.query.filter_by(user_id=current_user.id).order_by(Criterion.id).all()
        num_existing = len(existing_criteria)

        if request.method == 'POST':
            criteria_names = []
            for i in range(1, 11): 
                dropdown_name = request.form.get(f'crit_select_{i}')
                manual_name = request.form.get(f'crit_manual_{i}').strip()
                name = manual_name if manual_name else (dropdown_name if dropdown_name != '0' else None)
                
                if name:
                    # Check duplicate (case insensitive)
                    if any(name.lower() == existing.lower() for existing in criteria_names):
                        flash(f'Nama kriteria "{name}" duplikat. Harap gunakan nama yang berbeda.', 'danger')
                        return redirect(url_for('setup_criteria'))
                    criteria_names.append(name)
            
            if len(criteria_names) < 2:
                flash('Minimal harus ada 2 kriteria.', 'danger')
                return redirect(url_for('setup_criteria'))
            
            # Reset lama dan simpan baru
            Criterion.query.filter_by(user_id=current_user.id).delete(synchronize_session=False)
            db.session.commit()
            for name in criteria_names:
                db.session.add(Criterion(user_id=current_user.id, name=name))
            db.session.commit()
            return redirect(url_for('index'))

        criteria_slots = [{'slot': i+1, 'name': (existing_criteria[i].name if i < num_existing else '')} for i in range(10)]
        return render_template('setup_criteria.html', criteria_slots=criteria_slots, common_criteria=COMMON_CRITERIA)

    # --- Rute Otentikasi ---
    @app.route('/register', methods=['GET', 'POST'])
    def register():
        if current_user.is_authenticated:
            return redirect(url_for('index'))
        if request.method == 'POST':
            username = request.form.get('username')
            password = request.form.get('password')
            if User.query.filter_by(username=username).first():
                flash('Username sudah terdaftar.', 'danger')
                return redirect(url_for('register'))
            user = User(username=username)
            user.set_password(password)
            db.session.add(user)
            db.session.commit()
            flash('Registrasi sukses. Silakan Login.', 'success')
            return redirect(url_for('login'))
        return render_template('register.html')

    @app.route('/login', methods=['GET', 'POST'])
    def login():
        if current_user.is_authenticated:
            return redirect(url_for('index'))
        if request.method == 'POST':
            username = request.form.get('username')
            password = request.form.get('password')
            user = User.query.filter_by(username=username).first()
            if user and user.check_password(password):
                login_user(user)
                return redirect(url_for('index'))
            flash('Login gagal.', 'danger')
        return render_template('login.html')

    @app.route('/logout')
    @login_required
    def logout():
        logout_user()
        logout_user()
        return redirect(url_for('landing'))

    # --- Rute Voting ---
    @app.route('/create_voting', methods=['POST'])
    @login_required
    def create_voting():
        # 1. Ambil kriteria user
        criteria = Criterion.query.filter_by(user_id=current_user.id).all()
        if not criteria:
            flash("Belum ada kriteria.", "danger")
            return redirect(url_for('index'))
            
        # 2. Buat Session
        session = VotingSession(user_id=current_user.id)
        db.session.add(session)
        db.session.commit() # Commit to get ID and ensure unique token
        
        # 3. Generate Skenario sesuai jumlah rank (kriteria)
        criteria_names = [c.name for c in criteria if c.name]
        num_scenarios = len(criteria_names)
        
        # Pastikan minimal 3 layout atau sesuai request "sesuai rank"
        # User request: "sesuai dengan berapa rank yang di input misalnya nanti ada 5 rank maka akan ada 5 skenario"
        # Jadi kita pakai len(criteria_names) mutlak.
        
        for i in range(1, num_scenarios + 1):
            # Acak rank
            shuffled_names = criteria_names[:]
            random.shuffle(shuffled_names)
            
            # Buat rank input dict: {name: rank_int} (1-based)
            rank_input = {name: idx+1 for idx, name in enumerate(shuffled_names)}
            
            # Hitung ROC
            final_scores, error = calculate_spk_roc(current_user.id, rank_input)
            
            if not error:
                # Simpan hasil teratas (Top 5 for summary)
                top_results = final_scores.head(5).to_dict() # {AltName: Score}
                
                # Buat Option
                option = VotingOption(
                    session_id=session.id,
                    scenario_name=f"Skenario {i}",
                    rank_configuration=json.dumps(rank_input),
                    result_summary=json.dumps(top_results)
                )
                db.session.add(option)
        
        db.session.commit()
        return redirect(url_for('voting_created', token=session.token))

    @app.route('/vote_created/<token>')
    @login_required
    def voting_created(token):
        session = VotingSession.query.filter_by(token=token).first_or_404()
        options = VotingOption.query.filter_by(session_id=session.id).all()
        
        # Parse for display
        display_options = []
        for opt in options:
            results = json.loads(opt.result_summary)
            sorted_results = sorted(results.items(), key=lambda x: x[1], reverse=True)
            top_winner = f"{sorted_results[0][0]} ({sorted_results[0][1]:.4f})" if sorted_results else "N/A"
            display_options.append({
                'name': opt.scenario_name,
                'winner': top_winner
            })
            
        return render_template('voting_created.html', token=token, options=display_options)

    @app.route('/vote/<token>')
    def vote_ui(token):
        # Public route
        session = VotingSession.query.filter_by(token=token).first_or_404()
        options = VotingOption.query.filter_by(session_id=session.id).all()
        
        parsed_options = []
        for opt in options:
            ranks = json.loads(opt.rank_configuration)
            # Sort rank text for display: "CritA > CritB > CritC"
            sorted_ranks = sorted(ranks, key=ranks.get)
            rank_text = " > ".join(sorted_ranks[:3]) + ("..." if len(sorted_ranks) > 3 else "")
            
            results = json.loads(opt.result_summary)
            # Sort results by score desc
            sorted_results = sorted(results.items(), key=lambda x: x[1], reverse=True)
            winner_text = f"{sorted_results[0][0]} ({sorted_results[0][1]:.4f})" if sorted_results else "N/A"
            
            parsed_options.append({
                'id': opt.id,
                'name': opt.scenario_name,
                'rank_text': rank_text,
                'winner': winner_text,
                'vote_count': opt.vote_count
            })
            
        return render_template('voting.html', token=token, options=parsed_options)

    @app.route('/vote/<token>/submit', methods=['POST'])
    def submit_vote(token):
        option_id = request.form.get('option_id')
        if option_id:
            option = VotingOption.query.get(option_id)
            if option:
                option.vote_count += 1
                db.session.commit()
                flash('Terima kasih! Suara Anda telah disimpan.', 'success')
        return redirect(url_for('vote_ui', token=token))


    # --- Rute Input Alternatif & Result (Lengkap) ---
    @app.route('/input', methods=['GET', 'POST'])
    @login_required
    def input_data():
        criteria = Criterion.query.filter_by(user_id=current_user.id).all()
        if request.method == 'POST':
            alt_name = request.form.get('alternative_name').strip()
            alt = Alternative.query.filter_by(user_id=current_user.id, name=alt_name).first()
            if not alt:
                alt = Alternative(user_id=current_user.id, name=alt_name)
                db.session.add(alt)
                db.session.commit()
            for crit in criteria:
                score_val = request.form.get(f'score_{crit.id}', 0)
                try:
                    score_int = int(score_val)
                    if not (1 <= score_int <= 5):
                        raise ValueError("Score out of range")
                except ValueError:
                    flash(f"Nilai untuk kriteria {crit.name} harus antara 1-5.", "danger")
                    return redirect(url_for('input_data'))
                    
                score_obj = Score.query.filter_by(alternative_id=alt.id, criterion_id=crit.id).first()
                if not score_obj:
                    score_obj = Score(alternative_id=alt.id, criterion_id=crit.id)
                    db.session.add(score_obj)
                score_obj.score_value = score_int
            db.session.commit()
            return redirect(url_for('index'))
        return render_template('criteria_input.html', criteria=criteria)

    # --- Rute Edit Alternatif ---
    @app.route('/edit_alternative/<int:id>', methods=['GET', 'POST'])
    @login_required
    def edit_alternative(id):
        alt = Alternative.query.get_or_404(id)
        # Pastikan milik user yang login
        if alt.user_id != current_user.id:
            flash("Akses ditolak.", "danger")
            return redirect(url_for('index'))
            
        criteria = Criterion.query.filter_by(user_id=current_user.id).all()
        
        if request.method == 'POST':
            # Update nama (jika ada perubahan)
            new_name = request.form.get('alternative_name').strip()
            if new_name and new_name != alt.name:
                alt.name = new_name
            
            # Update skor
            for crit in criteria:
                score_val = request.form.get(f'score_{crit.id}', 0)
                try:
                    score_int = int(score_val)
                    if not (1 <= score_int <= 5):
                        raise ValueError("Score out of range")
                except ValueError:
                    flash(f"Nilai untuk kriteria {crit.name} harus antara 1-5.", "danger")
                    return redirect(url_for('edit_alternative', id=id))

                score_obj = Score.query.filter_by(alternative_id=alt.id, criterion_id=crit.id).first()
                if not score_obj:
                    score_obj = Score(alternative_id=alt.id, criterion_id=crit.id)
                    db.session.add(score_obj)
                score_obj.score_value = score_int
                
            db.session.commit()
            flash('Data alternatif berhasil diperbarui.', 'success')
            return redirect(url_for('index'))
            
        # Pre-fill scores
        scores = {}
        for crit in criteria:
            s_obj = Score.query.filter_by(alternative_id=alt.id, criterion_id=crit.id).first()
            scores[crit.id] = s_obj.score_value if s_obj else 0
            
        return render_template('edit_alternative.html', alternative=alt, criteria=criteria, scores=scores)


    @app.route('/result', methods=['POST'])
    @login_required
    def result():
        criteria = Criterion.query.filter_by(user_id=current_user.id).all()
        rank_input = {}
        for crit in criteria:
            rank_val = request.form.get(f'rank_{crit.id}', '0')
            if rank_val != '0':
                rank_input[crit.name] = int(rank_val)
        
        # Validasi: Rank harus unik
        rank_values = list(rank_input.values())
        if len(set(rank_values)) != len(rank_values):
            flash("Setiap kriteria harus memiliki ranking UNIK (tidak boleh ada ranking yang sama).", "danger")
            return redirect(url_for('index'))
            
        if len(rank_input) < 2:
            flash("Minimal harus ada 2 kriteria untuk dihitung.", "danger")
            return redirect(url_for('index'))

        final_scores_series, error = calculate_spk_roc(current_user.id, rank_input)
        if error:
            flash(error, 'danger')
            return redirect(url_for('index'))
        
        final_scores_list = final_scores_series.reset_index().values.tolist()
        sorted_rank_keys = sorted(rank_input, key=rank_input.get) 
        display_weights = [{'name': k, 'user_rank': rank_input[k], 'final_weight': FIXED_ROC_WEIGHTS[i]} 
                           for i, k in enumerate(sorted_rank_keys)]
        
        return render_template('result.html', final_scores=final_scores_list, display_weights=display_weights)

    return app

if __name__ == '__main__':
    app = create_app()
    app.run(debug=True)