# config.py

class Config:
    # MENGGUNAKAN DRIVER 'mysql-connector-python'
    # Skema: mysql+mysqlconnector://[USER]:[PASSWORD]@[HOST]:[PORT]/[DB_NAME]
    SQLALCHEMY_DATABASE_URI = 'mysql+mysqlconnector://root:@localhost:3306/roc_spk_db'
    
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    SECRET_KEY = 'kunci_rahasia_yang_kuat'