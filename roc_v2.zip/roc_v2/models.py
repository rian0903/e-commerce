
from datetime import datetime
import uuid
import json

from flask_login import UserMixin, LoginManager
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash

# INISIALISASI INSTANCE EKSTENSI
db = SQLAlchemy()
login_manager = LoginManager()

@login_manager.user_loader
def load_user(user_id):
    """Fungsi wajib Flask-Login untuk memuat user dari ID"""
    return db.session.get(User, int(user_id))

# --- Model Otentikasi ---

class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(64), unique=True, nullable=False)
    password_hash = db.Column(db.String(256)) 
    
    # Hubungan baru: User memiliki Kriteria
    criteria = db.relationship('Criterion', backref='creator', lazy='dynamic', cascade="all, delete-orphan")
    alternatives = db.relationship('Alternative', backref='owner', lazy='dynamic', cascade="all, delete-orphan")

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)

# --- Model SPK ---
    
class Criterion(db.Model):
    """Kriteria dibuat dan dimiliki oleh user."""
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    name = db.Column(db.String(100), nullable=False)
    # Tidak ada lagi bobot_roc di sini

    __table_args__ = (db.UniqueConstraint('user_id', 'name', name='_user_crit_uc'),)

# Model Alternative dan Score tetap sama

class Alternative(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    name = db.Column(db.String(100), nullable=False)
    
    scores = db.relationship('Score', backref='alternative', lazy='dynamic', cascade="all, delete-orphan")

class Score(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    alternative_id = db.Column(db.Integer, db.ForeignKey('alternative.id'), nullable=False)
    criterion_id = db.Column(db.Integer, db.ForeignKey('criterion.id'), nullable=False)
    score_value = db.Column(db.Integer, nullable=False) 
    
    __table_args__ = (db.UniqueConstraint('alternative_id', 'criterion_id', name='_alt_crit_uc'),)

# --- Model Voting ---

class VotingSession(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    token = db.Column(db.String(36), unique=True, index=True, default=lambda: str(uuid.uuid4()))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    options = db.relationship('VotingOption', backref='session', lazy='dynamic', cascade="all, delete-orphan")

class VotingOption(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    session_id = db.Column(db.Integer, db.ForeignKey('voting_session.id'), nullable=False)
    scenario_name = db.Column(db.String(50)) # e.g. "Scenario A"
    rank_configuration = db.Column(db.Text) # JSON string of rank used: {"CritA": 1, "CritB": 2...}
    result_summary = db.Column(db.Text) # JSON string of top result: {"AltA": 0.9, "AltB": 0.8...}
    vote_count = db.Column(db.Integer, default=0)
