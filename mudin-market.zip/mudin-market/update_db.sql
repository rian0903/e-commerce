-- Migration Script: Indonesian DB -> English DB

-- 1. Rename Tables
RENAME TABLE produk TO products;
RENAME TABLE pesanan TO orders;
RENAME TABLE detail_pesanan TO order_items;

-- 2. Update Users Table
ALTER TABLE users CHANGE COLUMN nama name VARCHAR(100) NOT NULL;
-- Add missing columns if they don't exist
ALTER TABLE users ADD COLUMN IF NOT EXISTS is_verified TINYINT(1) NOT NULL DEFAULT 0;
ALTER TABLE users ADD COLUMN IF NOT EXISTS created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP;

-- 3. Update Products Table
ALTER TABLE products CHANGE COLUMN nama_produk name VARCHAR(255) NOT NULL;
ALTER TABLE products CHANGE COLUMN deskripsi description TEXT;
ALTER TABLE products CHANGE COLUMN harga price DECIMAL(10,2) NOT NULL;
ALTER TABLE products CHANGE COLUMN stok stock INT(11) NOT NULL DEFAULT 0;
ALTER TABLE products CHANGE COLUMN gambar image VARCHAR(255) NULL;
ALTER TABLE products ADD COLUMN IF NOT EXISTS created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP;

-- 4. Update Orders Table
ALTER TABLE orders CHANGE COLUMN tgl_pesan created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP;
ALTER TABLE orders CHANGE COLUMN total_bayar total_amount DECIMAL(10,2) NOT NULL;
ALTER TABLE orders MODIFY COLUMN status ENUM('pending','confirmed','shipped','completed','cancelled') NOT NULL DEFAULT 'pending';

-- 5. Update Order Items Table
ALTER TABLE order_items CHANGE COLUMN pesanan_id order_id INT(11) NOT NULL;
ALTER TABLE order_items CHANGE COLUMN produk_id product_id INT(11) NOT NULL;
ALTER TABLE order_items CHANGE COLUMN qty quantity INT(11) NOT NULL;
-- Add price column (unit price)
ALTER TABLE order_items ADD COLUMN IF NOT EXISTS price DECIMAL(10,2) NOT NULL DEFAULT 0;
-- Attempt to calculate unit price from subtotal if subtotal exists. 
-- Note: MySQL might error on DROP if column doesn't exist, we'll try carefully.
-- IF subtotal column exists:
UPDATE order_items SET price = subtotal / quantity WHERE quantity > 0;
ALTER TABLE order_items DROP COLUMN subtotal;

-- 6. Create Payments Table
CREATE TABLE IF NOT EXISTS `payments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL,
  `payment_method` varchar(50) NOT NULL,
  `payment_status` enum('pending','verified','failed') NOT NULL DEFAULT 'pending',
  `proof_image` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `order_id` (`order_id`),
  CONSTRAINT `payments_ibfk_3` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
