-- Fix Products Table
ALTER TABLE products CHANGE COLUMN nama_produk name VARCHAR(255) NOT NULL;
ALTER TABLE products CHANGE COLUMN deskripsi description TEXT;
ALTER TABLE products CHANGE COLUMN harga price DECIMAL(10,2) NOT NULL;
ALTER TABLE products CHANGE COLUMN stok stock INT(11) NOT NULL DEFAULT 0;
ALTER TABLE products CHANGE COLUMN gambar image VARCHAR(255) NULL;
ALTER TABLE products ADD COLUMN created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP;

-- Fix Orders Table
ALTER TABLE orders CHANGE COLUMN tgl_pesan created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP;
ALTER TABLE orders CHANGE COLUMN total_bayar total_amount DECIMAL(10,2) NOT NULL;
ALTER TABLE orders MODIFY COLUMN status ENUM('pending','confirmed','shipped','completed','cancelled') NOT NULL DEFAULT 'pending';

-- Fix Order Items Table
-- First, rename foreign keys columns
ALTER TABLE order_items CHANGE COLUMN pesanan_id order_id INT(11) NOT NULL;
ALTER TABLE order_items CHANGE COLUMN produk_id product_id INT(11) NOT NULL;
ALTER TABLE order_items CHANGE COLUMN qty quantity INT(11) NOT NULL;

-- Convert subtotal to unit price
ALTER TABLE order_items ADD COLUMN price DECIMAL(10,2) NOT NULL DEFAULT 0;
UPDATE order_items SET price = subtotal / quantity WHERE quantity > 0;
ALTER TABLE order_items DROP COLUMN subtotal;
