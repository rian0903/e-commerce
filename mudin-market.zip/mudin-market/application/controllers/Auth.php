<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Auth extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('Auth_model');
        $this->load->library('form_validation');
    }

    public function login() {
        if ($this->session->userdata('user_id')) {
            redirect('home');
        }

        $this->form_validation->set_rules('email', 'Email', 'required|valid_email');
        $this->form_validation->set_rules('password', 'Password', 'required');

        if ($this->form_validation->run() === FALSE) {
            $this->load->view('auth/login');
        } else {
            $email = $this->input->post('email');
            $password = $this->input->post('password');

            $user = $this->Auth_model->login($email, $password);

            if ($user) {
                if ($user->is_verified == 0 && $user->role != 'admin') {
                     $this->session->set_flashdata('error', 'Please verify your email address.');
                     redirect('auth/login');
                }
                
                $session_data = array(
                    'user_id' => $user->id,
                    'name' => $user->name,
                    'email' => $user->email,
                    'role' => $user->role,
                    'logged_in' => TRUE
                );
                $this->session->set_userdata($session_data);

                if ($user->role == 'admin') {
                    redirect('admin');
                } else {
                    redirect('home');
                }
            } else {
                $this->session->set_flashdata('error', 'Invalid email or password');
                redirect('auth/login');
            }
        }
    }

    public function register() {
         if ($this->session->userdata('user_id')) {
            redirect('home');
        }

        $this->form_validation->set_rules('name', 'Name', 'required');
        $this->form_validation->set_rules('email', 'Email', 'required|valid_email|is_unique[users.email]');
        $this->form_validation->set_rules('password', 'Password', 'required|min_length[6]');
        $this->form_validation->set_rules('confirm_password', 'Confirm Password', 'required|matches[password]');

        if ($this->form_validation->run() === FALSE) {
            $this->load->view('auth/register');
        } else {
            $data = array(
                'name' => $this->input->post('name'),
                'email' => $this->input->post('email'),
                'password' => password_hash($this->input->post('password'), PASSWORD_BCRYPT),
                'role' => 'user',
                'is_verified' => 0 // Email verification required
            );

            if ($this->Auth_model->register($data)) {
                // Simplified email sending logic (stub)
                // In real world, send email here.
                // SIMULATION: Providing a link to verify immediately for testing
                $verify_link = base_url('auth/verify?email=' . urlencode($data['email']));
                $msg = 'Registration successful! <br><strong>SIMULATION:</strong> <a href="'.$verify_link.'">Click here to Verify Email</a>';
                
                $this->session->set_flashdata('success', $msg);
                redirect('auth/login');
            } else {
                $this->session->set_flashdata('error', 'Registration failed. Please try again.');
                redirect('auth/register');
            }
        }
    }

    public function verify() {
        $email = $this->input->get('email');
        if ($email) {
            $this->Auth_model->verify_email(urldecode($email));
            $this->session->set_flashdata('success', 'Email verified successfully! You can now login.');
        } else {
            $this->session->set_flashdata('error', 'Invalid verification link.');
        }
        redirect('auth/login');
    }

    public function logout() {
        $this->session->sess_destroy();
        redirect('auth/login');
    }
}
