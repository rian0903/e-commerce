<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('Product_model');
    }

    public function index() {
        $data['products'] = $this->Product_model->get_all_products();
        $this->load->view('landing/index', $data);
    }

    public function detail($id) {
        $product = $this->Product_model->get_product($id);
        if (!$product) show_404();
        
        $data['product'] = $product;
        // Also fetch related or recent products if needed, for now just detail
        $this->load->view('landing/detail', $data);
    }
}
