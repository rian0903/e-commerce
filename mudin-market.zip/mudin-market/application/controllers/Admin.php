<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('Product_model');
        $this->load->model('Order_model'); // Will implement later
        $this->load->library('form_validation');
        $this->load->helper('text'); // Explicitly load to fix humanize error
        
        // Check if admin is logged in
        if (!$this->session->userdata('logged_in') || $this->session->userdata('role') !== 'admin') {
            redirect('auth/login');
        }
    }

    public function index() {
        $this->load->view('admin/dashboard');
    }

    public function products() {
        $data['products'] = $this->Product_model->get_all_products();
        $this->load->view('admin/products', $data);
    }

    public function reports() {
        // Simple report: Total sales by status
        $this->db->select('status, COUNT(*) as count, SUM(total_amount) as total');
        $this->db->group_by('status');
        $data['status_counts'] = $this->db->get('orders')->result();
        
        // Monthly sales
        $this->db->select("DATE_FORMAT(created_at, '%Y-%m') as month, SUM(total_amount) as total");
        $this->db->group_by('month');
        $this->db->order_by('month', 'DESC');
        $data['monthly_sales'] = $this->db->get('orders')->result();

        $this->load->view('admin/reports', $data);
    }

    public function orders() {
        // Use the Order_model we created
        $data['orders'] = $this->Order_model->get_all_orders();
        $this->load->view('admin/orders', $data);
    }

    public function update_order_status($id, $status) {
        $valid_statuses = ['pending', 'confirmed', 'shipped', 'completed', 'cancelled'];
        if (in_array($status, $valid_statuses)) {
            if ($status == 'cancelled') {
                $this->Order_model->delete_order($id);
                $this->session->set_flashdata('success', 'Order cancelled and deleted successfully.');
            } else {
                $this->Order_model->update_status($id, $status);
                $this->session->set_flashdata('success', 'Order status updated to ' . $status);
            }
        }
        redirect('admin/orders');
    }

    public function update_location() {
        $order_id = $this->input->post('order_id');
        $lat = $this->input->post('latitude');
        $long = $this->input->post('longitude');
        
        // Direct DB update for now or via Model if exists
        $this->db->where('id', $order_id);
        $this->db->update('orders', array(
            'current_latitude' => $lat,
            'current_longitude' => $long
        ));
        
        $this->session->set_flashdata('success', 'Package location updated.');
        redirect('admin/orders');
    }

    public function add_product() {
        $this->form_validation->set_rules('name', 'Product Name', 'required');
        $this->form_validation->set_rules('price', 'Price', 'required|numeric');
        $this->form_validation->set_rules('stock', 'Stock', 'required|integer');

        if ($this->form_validation->run() === FALSE) {
            $this->load->view('admin/product_form');
        } else {
            // Handle File Upload
            $config['upload_path'] = './assets/uploads/products/';
            $config['allowed_types'] = 'gif|jpg|png|jpeg';
            $config['file_name'] = time() . '_' . $_FILES['image']['name'];
            
            // Check if directory exists, if not create it
            if (!is_dir($config['upload_path'])) {
                mkdir($config['upload_path'], 0777, true);
            }

            $this->load->library('upload', $config);

            $image = '';
            if ($this->upload->do_upload('image')) {
                $upload_data = $this->upload->data();
                $image = $upload_data['file_name'];
            }

            $data = array(
                'name' => $this->input->post('name'),
                'description' => $this->input->post('description'),
                'price' => $this->input->post('price'),
                'stock' => $this->input->post('stock'),
                'image' => $image
            );

            if ($this->Product_model->insert_product($data)) {
                $this->session->set_flashdata('success', 'Product added successfully');
                redirect('admin/products');
            } else {
                $this->session->set_flashdata('error', 'Failed to add product');
                redirect('admin/add_product');
            }
        }
    }

    public function edit_product($id) {
         $data['product'] = $this->Product_model->get_product($id);
         if(!$data['product']) show_404();

        $this->form_validation->set_rules('name', 'Product Name', 'required');
        $this->form_validation->set_rules('price', 'Price', 'required|numeric');
        $this->form_validation->set_rules('stock', 'Stock', 'required|integer');

        if ($this->form_validation->run() === FALSE) {
            $this->load->view('admin/product_form', $data);
        } else {
             // Handle File Upload
            $config['upload_path'] = './assets/uploads/products/';
            $config['allowed_types'] = 'gif|jpg|png|jpeg';
            $config['file_name'] = time() . '_' . $_FILES['image']['name'];
            
             // Check if directory exists, if not create it
            if (!is_dir($config['upload_path'])) {
                mkdir($config['upload_path'], 0777, true);
            }

            $this->load->library('upload', $config);

            $data_update = array(
                'name' => $this->input->post('name'),
                'description' => $this->input->post('description'),
                'price' => $this->input->post('price'),
                'stock' => $this->input->post('stock')
            );

            if (!empty($_FILES['image']['name'])) {
                 if ($this->upload->do_upload('image')) {
                    $upload_data = $this->upload->data();
                    $data_update['image'] = $upload_data['file_name'];
                }
            }

            if ($this->Product_model->update_product($id, $data_update)) {
                $this->session->set_flashdata('success', 'Product updated successfully');
                redirect('admin/products');
            } else {
                $this->session->set_flashdata('error', 'Failed to update product');
                redirect('admin/edit_product/'.$id);
            }
        }
    }

    public function delete_product($id) {
        $this->Product_model->delete_product($id);
        $this->session->set_flashdata('success', 'Product deleted successfully');
        redirect('admin/products');
    }

    public function export_excel() {
        // Fetch data (same as reports)
        $this->db->select('status, COUNT(*) as count, SUM(total_amount) as total');
        $this->db->group_by('status');
        $status_counts = $this->db->get('orders')->result();
        
        $this->db->select("DATE_FORMAT(created_at, '%Y-%m') as month, SUM(total_amount) as total");
        $this->db->group_by('month');
        $this->db->order_by('month', 'DESC');
        $monthly_sales = $this->db->get('orders')->result();

        // Check if data exists
        if (empty($status_counts) && empty($monthly_sales)) {
             $this->session->set_flashdata('error', 'No data to export');
             redirect('admin/reports');
        }

        // Set headers for CSV download
        $filename = 'report_sales_' . date('Ymd') . '.csv';
        header("Content-Description: File Transfer");
        header("Content-Disposition: attachment; filename=$filename");
        header("Content-Type: application/csv; "); 
        
        // Open output stream
        $file = fopen('php://output', 'w');
        
        // Sheet 1 equivalent: Sales by Status
        fputcsv($file, array('SALES BY STATUS'));
        fputcsv($file, array('Status', 'Count', 'Total Amount'));
        foreach ($status_counts as $row) {
            fputcsv($file, array(ucfirst($row->status), $row->count, $row->total));
        }
        
        fputcsv($file, array('')); // Empty line
        
        // Sheet 2 equivalent: Monthly Sales
        fputcsv($file, array('MONTHLY SALES'));
        fputcsv($file, array('Month', 'Total Amount'));
        foreach ($monthly_sales as $row) {
             fputcsv($file, array($row->month, $row->total));
        }

        fclose($file);
        exit;
    }

    public function export_pdf() {
        // Fetch data
        $this->db->select('status, COUNT(*) as count, SUM(total_amount) as total');
        $this->db->group_by('status');
        $data['status_counts'] = $this->db->get('orders')->result();
        
        $this->db->select("DATE_FORMAT(created_at, '%Y-%m') as month, SUM(total_amount) as total");
        $this->db->group_by('month');
        $this->db->order_by('month', 'DESC');
        $data['monthly_sales'] = $this->db->get('orders')->result();

        // Load DOMPDF
        // Namespaced class usage requires composer autoload
        $options = new \Dompdf\Options();
        $options->set('isRemoteEnabled', TRUE);
        $dompdf = new \Dompdf\Dompdf($options);
        
        // Load view
        $html = $this->load->view('admin/reports_pdf', $data, TRUE);
        
        $dompdf->loadHtml($html);
        
        // (Optional) Setup the paper size and orientation
        $dompdf->setPaper('A4', 'portrait'); // or landscape
        
        // Render the HTML as PDF
        $dompdf->render();
        
        // Output the generated PDF to Browser
        $dompdf->stream('report_sales_' . date('Ymd') . '.pdf', array("Attachment" => TRUE));
    }
}
