<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('Product_model');
        $this->load->model('Order_model');
        $this->load->model('Auth_model'); // Checking if we can reuse or just use db directly
        
        // Security: Ensure user is logged in for everything except cart manipulation may be? 
        // Actually, let's allow cart for guests but force login at checkout.
        // For Dashboard, must be logged in.
    }

    public function index() {
        if (!$this->session->userdata('logged_in')) redirect('auth/login');
        
        $user_id = $this->session->userdata('user_id');
        
        // Fetch full user data from DB to get created_at
        $this->db->where('id', $user_id);
        $data['user'] = $this->db->get('users')->row();
        
        $data['orders'] = $this->Order_model->get_user_orders($user_id);
        
        $this->load->view('user/dashboard', $data);
    }

    public function cart() {
        $this->load->view('user/cart');
    }

    public function add_to_cart($id) {
        $product = $this->Product_model->get_product($id);
        if (!$product) show_404();

        $data = array(
            'id'      => $product->id,
            'qty'     => 1,
            'price'   => $product->price,
            'name'    => $product->name,
            'options' => array('image' => $product->image)
        );

        $this->cart->insert($data);
        $this->session->set_flashdata('success', 'Product added to cart!');
        redirect('user/cart');
    }

    public function update_cart() {
        $data = $this->input->post();
        $this->cart->update($data);
        redirect('user/cart');
    }

    public function remove_cart($rowid) {
        $this->cart->remove($rowid);
        redirect('user/cart');
    }

    public function checkout() {
        if (!$this->session->userdata('logged_in')) {
             $this->session->set_flashdata('error', 'Please login to checkout.');
             redirect('auth/login');
        }

        if ($this->cart->total_items() <= 0) {
            redirect('user/cart');
        }

        $this->load->view('user/checkout');
    }

    public function track_order($order_id) {
         if (!$this->session->userdata('logged_in')) redirect('auth/login');
         
         // Get order details
         // Assuming Order Model has get_order or we use direct DB
         $this->db->where('id', $order_id);
         $this->db->where('user_id', $this->session->userdata('user_id'));
         $order = $this->db->get('orders')->row();
         
         if (!$order) show_404();
         
         $data['order'] = $order;
         $this->load->view('user/track_order', $data);
    }

    public function place_order() {
         if (!$this->session->userdata('logged_in')) redirect('auth/login');

         // Validation
         $this->load->library('form_validation');
         $this->form_validation->set_rules('address', 'Address', 'required');
         $this->form_validation->set_rules('payment_method', 'Payment Method', 'required');

         if ($this->form_validation->run() === FALSE) {
             $this->load->view('user/checkout');
         } else {
             // Save Order
             $order_data = array(
                 'user_id' => $this->session->userdata('user_id'),
                 'total_amount' => $this->cart->total(),
                 'payment_method' => $this->input->post('payment_method'),
                 'shipping_courier' => $this->input->post('shipping_courier'),
                 'status' => 'pending',
                 'address' => $this->input->post('address'),
                 'latitude' => $this->input->post('latitude'),
                 'longitude' => $this->input->post('longitude')
             );
             
             // We need Order Model here. Let's create it inline or use db directly for speed if model not exists yet.
             // Im implementing simple direct DB here to save tool calls, or better, stick to plan and make model.
             // Let's make Order_model next. For now, assuming it exists or I'll add methods.
             
             // Wait, I haven't created Order_model yet. Use direct DB for now to show progress, or create model in next step.
             $this->db->insert('orders', $order_data);
             $order_id = $this->db->insert_id();

             // Save Order Items
             foreach ($this->cart->contents() as $items) {
                 $item_data = array(
                     'order_id' => $order_id,
                     'product_id' => $items['id'],
                     'quantity' => $items['qty'],
                     'price' => $items['price']
                 );
                 $this->db->insert('order_items', $item_data);
                 
                 // Reduce Stock
                 $this->Product_model->reduce_stock($items['id'], $items['qty']);
             }
             
             // Handle Payment Proof
             // If manual bank transfer, they might upload proof.
             
             $this->cart->destroy();
             $this->session->set_flashdata('success', 'Order placed successfully! Order ID: ' . $order_id);
             redirect('user');
         }
    }
}
