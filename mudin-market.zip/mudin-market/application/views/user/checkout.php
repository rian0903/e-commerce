<?php $this->load->view('templates/header'); ?>
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" integrity="sha256-p4NxAoJBhIIN+hmNHrzRCf9tD/miZyoHS5obTRR9BMY=" crossorigin=""/>
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js" integrity="sha256-20nQCchB9co0qIjJZRGuk2/Z9VM+kNiyxNV1lvTlZBo=" crossorigin=""></script>
<style>
    #map { height: 300px; width: 100%; border-radius: 8px; margin-top: 10px; z-index: 1; }
</style>

<div class="container py-5">
    <h2 class="fw-bold mb-4">Checkout</h2>
    <div class="row">
        <div class="col-md-8">
            <div class="card shadow-sm border-0 mb-4">
                <div class="card-header bg-white py-3">
                    <h5 class="mb-0">Shipping & Payment Details</h5>
                </div>
                <div class="card-body p-4">
                    <?= form_open('user/place_order'); ?>
                        <div class="mb-3">
                            <label class="form-label fw-bold">Delivery Address</label>
                            <textarea name="address" id="address_input" class="form-control" rows="3" required placeholder="Enter your full street address including city and zip code"></textarea>
                            <div id="map"></div>
                            <small class="text-muted">Drag the pin to pinpoint your exact location.</small>
                            <input type="hidden" name="longitude" id="longitude">
                        </div>
                        <div class="mb-3">
                            <label class="form-label fw-bold">Shipping Courier</label>
                            <select name="shipping_courier" class="form-select" required>
                                <option value="" selected disabled>Select a Courier</option>
                                <option value="JNE">JNE</option>
                                <option value="TIKI">TIKI</option>
                                <option value="POS Indonesia">POS Indonesia</option>
                                <option value="GoSend">GoSend</option>
                                <option value="GrabExpress">GrabExpress</option>
                            </select>
                        </div>
                        <div class="mb-4">
                            <label class="form-label fw-bold">Payment Method</label>
                            <div class="form-check card p-3 mb-2">
                                <input class="form-check-input" type="radio" name="payment_method" id="bank_transfer" value="bank_transfer" checked>
                                <label class="form-check-label d-flex justify-content-between w-100" for="bank_transfer">
                                    <span>Bank Transfer (BCA)</span>
                                    <span class="text-muted">No. 123456789</span>
                                </label>
                            </div>
                            <div class="form-check card p-3">
                                <input class="form-check-input" type="radio" name="payment_method" id="cod" value="cod">
                                <label class="form-check-label" for="cod">
                                    Cash on Delivery (COD)
                                </label>
                            </div>
                        </div>
                        <button type="submit" class="btn btn-success w-100 py-2 rounded-pill fw-bold">Place Order <i class="fas fa-check-circle ms-1"></i></button>
                    <?= form_close(); ?>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card shadow-sm border-0 bg-light">
                <div class="card-body p-4">
                    <h5 class="card-title fw-bold mb-3">Order Summary</h5>
                    <div class="d-flex justify-content-between mb-2">
                         <span>Total Items:</span>
                         <span class="fw-bold"><?= $this->cart->total_items(); ?></span>
                    </div>
                    <hr>
                    <div class="d-flex justify-content-between align-items-center">
                        <span class="fs-5">Total:</span>
                        <span class="fs-4 fw-bold text-success">Rp <?= number_format($this->cart->total(), 0, ',', '.'); ?></span>
                    </div>
                </div>
            </div>
            <div class="mt-3 text-center">
                 <a href="<?= base_url('user/cart'); ?>" class="text-decoration-none">Edit Cart</a>
            </div>
        </div>
    </div>
</div>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        // Default to Jakarta
        var defaultLat = -6.2088;
        var defaultLng = 106.8456;
        
        var map = L.map('map').setView([defaultLat, defaultLng], 13);

        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
        }).addTo(map);

        var marker = L.marker([defaultLat, defaultLng], {draggable: true}).addTo(map);

        function updateInputs(lat, lng) {
            document.getElementById('latitude').value = lat;
            document.getElementById('longitude').value = lng;
        }

        updateInputs(defaultLat, defaultLng);

        marker.on('dragend', function(e) {
            var position = marker.getLatLng();
            updateInputs(position.lat, position.lng);
        });

        // Geocoding logic
        var addressInput = document.getElementById('address_input');
        var timeout = null;

        addressInput.addEventListener('input', function() {
            clearTimeout(timeout);
            var query = this.value;
            if (query.length < 5) return;

            timeout = setTimeout(function() {
                fetch('https://nominatim.openstreetmap.org/search?format=json&q=' + encodeURIComponent(query))
                    .then(response => response.json())
                    .then(data => {
                        if (data && data.length > 0) {
                            var lat = parseFloat(data[0].lat);
                            var lon = parseFloat(data[0].lon);
                            
                            map.setView([lat, lon], 16);
                            marker.setLatLng([lat, lon]);
                            updateInputs(lat, lon);
                        }
                    })
                    .catch(error => console.error('Error:', error));
            }, 1000); // 1s debounce
        });
        
        // Try getting current location
        if (navigator.geolocation) {
            navigator.geolocation.getCurrentPosition(function(position) {
                var lat = position.coords.latitude;
                var lng = position.coords.longitude;
                map.setView([lat, lng], 16);
                marker.setLatLng([lat, lng]);
                updateInputs(lat, lng);
            });
        }
    });
</script>

<?php $this->load->view('templates/footer'); ?>
