<?php $this->load->view('templates/header'); ?>

<div class="container py-5">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2 class="fw-bold">Shopping Cart</h2>
    </div>
    
    <?php if($this->session->flashdata('success')): ?>
        <div class="alert alert-success"><?= $this->session->flashdata('success'); ?></div>
    <?php endif; ?>

    <?php if ($this->cart->total_items() > 0): ?>
        <?= form_open('user/update_cart'); ?>
        <div class="card shadow-sm border-0">
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-hover mb-0">
                        <thead class="bg-light">
                            <tr>
                                <th class="py-3 px-4">Item</th>
                                <th class="py-3 px-4">Price</th>
                                <th class="py-3 px-4">Qty</th>
                                <th class="py-3 px-4">Subtotal</th>
                                <th class="py-3 px-4">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $i = 1; ?>
                            <?php foreach ($this->cart->contents() as $items): ?>
                            <tr>
                                <td class="px-4 py-3 fw-bold"><?= $items['name']; ?></td>
                                <td class="px-4 py-3">Rp <?= number_format($items['price'], 0, ',', '.'); ?></td>
                                <td class="px-4 py-3"><input type="number" name="<?= $i.'[qty]'; ?>" value="<?= $items['qty']; ?>" min="1" class="form-control rounded-pill text-center" style="width: 70px;"></td>
                                <td class="px-4 py-3 text-primary fw-bold">Rp <?= number_format($items['subtotal'], 0, ',', '.'); ?></td>
                                <td class="px-4 py-3">
                                    <a href="<?= base_url('user/remove_cart/'.$items['rowid']); ?>" class="btn btn-danger btn-sm rounded-pill px-3">Remove</a>
                                </td>
                                <input type="hidden" name="<?= $i.'[rowid]'; ?>" value="<?= $items['rowid']; ?>">
                            </tr>
                            <?php $i++; ?>
                            <?php endforeach; ?>
                        </tbody>
                        <tfoot class="bg-light">
                            <tr>
                                <td colspan="3" class="text-end fw-bold py-3">Total</td>
                                <td colspan="2" class="fw-bold fs-5 text-success py-3">Rp <?= number_format($this->cart->total(), 0, ',', '.'); ?></td>
                            </tr>
                        </tfoot>
                    </table>
                </div>
            </div>
            <div class="card-footer bg-white p-4 d-flex justify-content-between align-items-center">
                 <a href="<?= base_url(); ?>" class="btn btn-outline-secondary rounded-pill px-4">Continue Shopping</a>
                 <div>
                    <button type="submit" class="btn btn-info text-white rounded-pill px-4 me-2">Update Cart</button>
                    <a href="<?= base_url('user/checkout'); ?>" class="btn btn-success rounded-pill px-4">Checkout</a>
                 </div>
            </div>
        </div>
        <?= form_close(); ?>
    <?php else: ?>
        <div class="text-center py-5">
            <div class="mb-3">
                <i class="fas fa-shopping-cart fa-4x text-muted"></i>
            </div>
            <h4 class="text-muted">Your cart is empty.</h4>
            <a href="<?= base_url(); ?>" class="btn btn-primary mt-3 rounded-pill px-5">Go Shopping</a>
        </div>
    <?php endif; ?>
</div>

<?php $this->load->view('templates/footer'); ?>
