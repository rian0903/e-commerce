<?php $this->load->view('templates/header'); ?>

<div class="container-fluid">
    <div class="row">
        <!-- Sidebar -->
         <?php $this->load->view('templates/user_sidebar'); ?>

        <!-- Main Content -->
        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 content-wrapper">
             <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                <h1 class="h2">My Dashboard</h1>
            </div>

            <div class="card mb-4 shadow-sm">
                <div class="card-header bg-white">
                    <h5 class="mb-0">Profile Information</h5>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-6">
                            <?php 
                                // Ideally passed from controller, but for safety in view
                                $user_name = $this->session->userdata('name');
                                $user_email = $this->session->userdata('email');
                                // If $user object is passed, use it, else session
                                if(isset($user)) {
                                    $user_name = $user->name;
                                    $user_email = $user->email;
                                    $created_at = $user->created_at;
                                }
                            ?>
                            <p><strong>Name:</strong> <?= $user_name; ?></p>
                            <p><strong>Email:</strong> <?= $user_email; ?></p>
                             <?php if(isset($created_at)): ?>
                                <p><strong>Member Since:</strong> <?= date('d M Y', strtotime($created_at)); ?></p>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="card shadow-sm">
                <div class="card-header bg-white">
                    <h5 class="mb-0">Order History</h5>
                </div>
                <div class="card-body">
                    <?php if(!empty($orders)): ?>
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th>Order ID</th>
                                        <th>Date</th>
                                        <th>Total Amount</th>
                                        <th>Status</th>
                                </thead>
                                <tbody>
                                    <?php foreach($orders as $order): ?>
                                    <tr>
                                        <td>#<?= $order->id; ?></td>
                                        <td><?= date('d M Y H:i', strtotime($order->created_at)); ?></td>
                                        <td>Rp <?= number_format($order->total_amount, 0, ',', '.'); ?></td>
                                        <td>
                                            <?php 
                                            // Badge logic
                                            $badge = 'secondary';
                                            if ($order->status == 'pending') $badge = 'warning';
                                            elseif ($order->status == 'confirmed') $badge = 'primary';
                                            elseif ($order->status == 'shipped') $badge = 'info';
                                            elseif ($order->status == 'completed') $badge = 'success';
                                            elseif ($order->status == 'cancelled') $badge = 'danger';
                                            ?>
                                            <span class="badge bg-<?= $badge; ?>">
                                                <?= ucfirst($order->status); ?>
                                            </span>
                                            <?php if($order->status == 'shipped' || $order->status == 'confirmed'): ?>
                                                <a href="<?= base_url('user/track_order/'.$order->id); ?>" class="btn btn-sm btn-outline-info ms-2">
                                                    <i class="fas fa-map-marker-alt"></i> Track
                                                </a>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php else: ?>
                        <div class="text-center py-4">
                            <p class="text-muted mb-3">You haven't placed any orders yet.</p>
                            <a href="<?= base_url(); ?>" class="btn btn-primary">Start Shopping</a>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </main>
    </div>
</div>

<?php $this->load->view('templates/footer'); ?>
