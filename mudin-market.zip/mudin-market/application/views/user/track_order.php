<?php $this->load->view('templates/header'); ?>
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" integrity="sha256-p4NxAoJBhIIN+hmNHrzRCf9tD/miZyoHS5obTRR9BMY=" crossorigin=""/>
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js" integrity="sha256-20nQCchB9co0qIjJZRGuk2/Z9VM+kNiyxNV1lvTlZBo=" crossorigin=""></script>
<style>
    #map { height: 400px; width: 100%; border-radius: 8px; margin-top: 20px; z-index: 1; }
</style>

<div class="container py-5">
    <div class="row mb-4">
        <div class="col-md-12">
            <h2 class="fw-bold">Track Order #<?= $order->id; ?></h2>
            <p class="text-muted">Status: <span class="badge bg-info text-dark"><?= ucfirst($order->status); ?></span></p>
        </div>
    </div>

    <div class="row">
        <div class="col-md-8">
            <div class="card shadow-sm border-0">
                <div class="card-body p-4">
                    <h5 class="fw-bold">Package Location</h5>
                    <div id="map"></div>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card shadow-sm border-0 bg-light">
                <div class="card-body p-4">
                    <h5 class="fw-bold mb-3">Order Details</h5>
                    <ul class="list-unstyled">
                        <li class="mb-2"><strong>Courier:</strong> <?= $order->shipping_courier ?: 'Not specified'; ?></li>
                        <li class="mb-2"><strong>Destination:</strong> <?= $order->address; ?></li>
                        <li class="mb-2"><strong>Total Amount:</strong> Rp <?= number_format($order->total_amount, 0, ',', '.'); ?></li>
                    </ul>
                    <a href="<?= base_url('user'); ?>" class="btn btn-secondary w-100">Back to Dashboard</a>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        // Order Destination
        var destLat = <?= $order->latitude ?: -6.2088; ?>;
        var destLng = <?= $order->longitude ?: 106.8456; ?>;
        
        // Current Package Location (default to destination if not set yet, or some hub)
        var currentLat = <?= $order->current_latitude ?: $order->latitude ?: -6.2088; ?>;
        var currentLng = <?= $order->current_longitude ?: $order->longitude ?: 106.8456; ?>;
        
        var map = L.map('map').setView([currentLat, currentLng], 13);

        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
        }).addTo(map);

        // Destination Marker
        var destIcon = L.icon({
            iconUrl: 'https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-red.png',
            shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/0.7.7/images/marker-shadow.png',
            iconSize: [25, 41],
            iconAnchor: [12, 41],
            popupAnchor: [1, -34],
            shadowSize: [41, 41]
        });

        // Package Marker (Truck or Blue)
        var packageIcon = L.icon({
            iconUrl: 'https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-blue.png',
            shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/0.7.7/images/marker-shadow.png',
            iconSize: [25, 41],
            iconAnchor: [12, 41],
            popupAnchor: [1, -34],
            shadowSize: [41, 41]
        });

        if (<?= $order->latitude ? 'true' : 'false'; ?>) {
            L.marker([destLat, destLng], {icon: destIcon}).addTo(map).bindPopup('Destination').openPopup();
        }

        if (<?= $order->current_latitude ? 'true' : 'false'; ?>) {
             L.marker([currentLat, currentLng], {icon: packageIcon}).addTo(map).bindPopup('Current Location');
        } else {
             // If no current location, maybe just show status
             L.popup()
                .setLatLng([destLat, destLng])
                .setContent("Package waiting for shipment.")
                .openOn(map);
        }
        
        // Fit bounds if both exist
        if (<?= ($order->latitude && $order->current_latitude) ? 'true' : 'false'; ?>) {
             var group = new L.featureGroup([
                 L.marker([destLat, destLng]),
                 L.marker([currentLat, currentLng])
             ]);
             map.fitBounds(group.getBounds().pad(0.1));
        }
    });
</script>

<?php $this->load->view('templates/footer'); ?>
