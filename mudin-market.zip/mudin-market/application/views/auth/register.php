<?php $this->load->view('templates/header'); ?>

<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-md-6">
            <div class="card shadow-lg border-0 rounded-3">
                <div class="card-header bg-secondary text-white text-center py-3">
                    <h3 class="mb-0 fw-bold">Register</h3>
                </div>
                <div class="card-body p-4">
                     <?php if($this->session->flashdata('error')): ?>
                        <div class="alert alert-danger"><?= $this->session->flashdata('error'); ?></div>
                    <?php endif; ?>

                    <?= form_open('auth/register'); ?>
                        <div class="mb-3">
                            <label class="form-label">Full Name</label>
                            <input type="text" name="name" class="form-control rounded-pill px-3" required value="<?= set_value('name'); ?>">
                             <?= form_error('name', '<small class="text-danger">', '</small>'); ?>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Email Address</label>
                             <input type="email" name="email" class="form-control rounded-pill px-3" required value="<?= set_value('email'); ?>">
                             <?= form_error('email', '<small class="text-danger">', '</small>'); ?>
                        </div>
                        <div class="mb-3">
                             <label class="form-label">Password</label>
                            <input type="password" name="password" class="form-control rounded-pill px-3" required>
                             <?= form_error('password', '<small class="text-danger">', '</small>'); ?>
                        </div>
                        <div class="mb-4">
                             <label class="form-label">Confirm Password</label>
                            <input type="password" name="confirm_password" class="form-control rounded-pill px-3" required>
                             <?= form_error('confirm_password', '<small class="text-danger">', '</small>'); ?>
                        </div>
                    <div class="d-grid gap-2">
                        <button type="submit" class="read_bt w-100 border-0" style="float:none;">Register</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $this->load->view('templates/footer'); ?>
