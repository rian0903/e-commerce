<div class="col-md-3 col-lg-2 sidebar collapse show" id="sidebarMenu">
    <div class="sidebar-header">
        Admin Panel
    </div>
    <div class="nav flex-column">
        <a href="<?= base_url('admin'); ?>" class="sidebar-link <?= ($this->uri->segment(2) == '' || $this->uri->segment(2) == 'index') ? 'active' : ''; ?>">
            <i class="fas fa-tachometer-alt me-2"></i> Dashboard
        </a>
        <a href="<?= base_url('admin/products'); ?>" class="sidebar-link <?= ($this->uri->segment(2) == 'products' || $this->uri->segment(2) == 'add_product' || $this->uri->segment(2) == 'edit_product') ? 'active' : ''; ?>">
            <i class="fas fa-box me-2"></i> Products
        </a>
        <a href="<?= base_url('admin/orders'); ?>" class="sidebar-link <?= ($this->uri->segment(2) == 'orders') ? 'active' : ''; ?>">
            <i class="fas fa-shopping-bag me-2"></i> Orders
        </a>
        <a href="<?= base_url('admin/reports'); ?>" class="sidebar-link <?= ($this->uri->segment(2) == 'reports') ? 'active' : ''; ?>">
            <i class="fas fa-chart-line me-2"></i> Reports
        </a>
        <a href="<?= base_url('auth/logout'); ?>" class="sidebar-link mt-5">
            <i class="fas fa-sign-out-alt me-2"></i> Logout
        </a>
    </div>
</div>
