<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mudin Market</title>
    <!-- Bootstrap 5 -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <!-- Custom Style -->
    <link rel="stylesheet" href="<?= base_url('assets/css/style.css'); ?>">
</head>
<body>

<div class="top_header">
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <span><i class="fas fa-envelope"></i> info@mudinmarket.com</span>
                <span class="ms-3"><i class="fas fa-phone"></i> +62 123 4567 890</span>
            </div>
            <div class="col-md-6 text-end">
                 <?php if($this->session->userdata('logged_in')): ?>
                     <span>Welcome, <?= $this->session->userdata('name'); ?></span>
                 <?php else: ?>
                    <a href="<?= base_url('auth/login'); ?>" class="text-white text-decoration-none me-2">Login</a>
                    <a href="<?= base_url('auth/register'); ?>" class="text-white text-decoration-none">Register</a>
                 <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<nav class="navbar navbar-expand-lg">
  <div class="container">
    <a class="navbar-brand" href="<?= base_url(); ?>">MUDIN MARKET</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
       <!-- Centered Search -->
       <form class="d-flex mx-auto header_search">
        <input class="search_input" type="search" placeholder="Search your product..." aria-label="Search">
        <button class="search_btn" type="submit"><i class="fas fa-search"></i></button>
      </form>
      
      <ul class="navbar-nav ms-auto mb-2 mb-lg-0">

        <?php if($this->session->userdata('role') == 'admin'): ?>
            <?php 
               $pending_count = $this->db->where('status', 'pending')->count_all_results('orders');
            ?>
            <li class="nav-item">
                <a class="nav-link" href="<?= base_url('admin/orders'); ?>">
                    <i class="fas fa-clipboard-list"></i> Orders 
                    <?php if($pending_count > 0): ?>
                        <span class="badge bg-danger rounded-pill"><?= $pending_count; ?></span>
                    <?php else: ?>
                        <span class="badge bg-secondary rounded-pill">0</span>
                    <?php endif; ?>
                </a>
            </li>
        <?php else: ?>
            <li class="nav-item">
                <a class="nav-link" href="<?= base_url('user/cart'); ?>">
                    <i class="fas fa-shopping-cart"></i> Cart 
                    <span class="badge bg-warning rounded-pill text-dark"><?= $this->cart->total_items(); ?></span>
                </a>
            </li>
        <?php endif; ?>
         <?php if($this->session->userdata('logged_in')): ?>
            <li class="nav-item dropdown">
                 <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">
                    <i class="fas fa-user"></i>
                 </a>
                 <ul class="dropdown-menu dropdown-menu-end">
                    <li><a class="dropdown-item" href="<?= base_url('user'); ?>">Dashboard</a></li>
                    <?php if($this->session->userdata('role') == 'admin'): ?>
                        <li><a class="dropdown-item" href="<?= base_url('admin'); ?>">Admin Panel</a></li>
                    <?php endif; ?>
                    <li><hr class="dropdown-divider"></li>
                    <li><a class="dropdown-item" href="<?= base_url('auth/logout'); ?>">Logout</a></li>
                 </ul>
            </li>
         <?php endif; ?>
      </ul>
    </div>
  </div>
</nav>
