<div class="col-md-3 col-lg-2 sidebar collapse show" id="sidebarMenu">
    <div class="sidebar-header">
        User Menu
    </div>
    <div class="nav flex-column">
        <a href="<?= base_url('user'); ?>" class="sidebar-link <?= ($this->uri->segment(2) == '' || $this->uri->segment(2) == 'index') ? 'active' : ''; ?>">
            <i class="fas fa-user me-2"></i> My Profile
        </a>
        <a href="<?= base_url(); ?>" class="sidebar-link">
            <i class="fas fa-arrow-left me-2"></i> Back to Shopping
        </a>
         <!-- Placeholder for Order History link if we separate it later, or keeps it under dashboard -->
        <a href="<?= base_url('auth/logout'); ?>" class="sidebar-link mt-5">
            <i class="fas fa-sign-out-alt me-2"></i> Logout
        </a>
    </div>
</div>
