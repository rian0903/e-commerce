<div class="footer_section">
    <div class="container">
        <div class="row">
            <div class="col-md-4">
                <h4 class="text-white mb-4">About Us</h4>
                <p>Mudin Market provides the best quality products at affordable prices. Shop with confidence.</p>
            </div>
            <div class="col-md-4">
                 <h4 class="text-white mb-4">Quick Links</h4>
                 <ul class="list-unstyled">
                     <li><a href="<?= base_url(); ?>" class="text-white text-decoration-none">Home</a></li>
                     <li><a href="#" class="text-white text-decoration-none">New Arrivals</a></li>
                     <li><a href="#" class="text-white text-decoration-none">Contact Us</a></li>
                 </ul>
            </div>
            <div class="col-md-4">
                <h4 class="text-white mb-4">Newsletter</h4>
                <div class="input-group mb-3">
                  <input type="text" class="form-control" placeholder="Enter your email">
                  <button class="btn btn-primary" type="button" style="background-color: var(--primary-color); border:none;">Subscribe</button>
                </div>
            </div>
        </div>
        <div class="location_main">
            <p>&copy; <?= date('Y'); ?> Mudin Market. All rights reserved.</p>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
