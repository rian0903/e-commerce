<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - Mudin Market</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

<?php $this->load->view('templates/header'); ?>

<div class="container-fluid">
    <div class="row">
        <!-- Sidebar -->
        <?php $this->load->view('templates/admin_sidebar'); ?>

        <!-- Main Content -->
        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 content-wrapper">
             <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                <h1 class="h2">Admin Dashboard</h1>
            </div>

            <div class="row">
                <div class="col-md-4">
                    <div class="card card-primary text-white bg-danger mb-3">
                        <div class="card-body">
                            <h5 class="card-title">Manage Products</h5>
                            <p class="card-text">View, add, edit, and delete products.</p>
                            <a href="<?= base_url('admin/products'); ?>" class="btn btn-light btn-sm">Go to Products</a>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card card-primary text-white bg-warning mb-3">
                        <div class="card-body">
                            <h5 class="card-title">Manage Orders</h5>
                            <p class="card-text">View and update customer orders.</p>
                            <a href="<?= base_url('admin/orders'); ?>" class="btn btn-light btn-sm">Go to Orders</a>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                     <div class="card card-primary text-white bg-success mb-3">
                        <div class="card-body">
                            <h5 class="card-title">Sales Reports</h5>
                            <p class="card-text">View sales analytics.</p>
                            <a href="<?= base_url('admin/reports'); ?>" class="btn btn-light btn-sm">View Reports</a>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
