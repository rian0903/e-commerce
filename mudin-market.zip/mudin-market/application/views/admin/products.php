<?php $this->load->view('templates/header'); ?>

<div class="container-fluid">
    <div class="row">
        <!-- Sidebar -->
        <?php $this->load->view('templates/admin_sidebar'); ?>

        <!-- Main Content -->
        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 content-wrapper">
            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                <h1 class="h2">Products</h1>
                <a href="<?= base_url('admin/add_product'); ?>" class="btn btn-primary">Add New Product</a>
            </div>

            <?php if($this->session->flashdata('success')): ?>
                <div class="alert alert-success"><?= $this->session->flashdata('success'); ?></div>
            <?php endif; ?>

            <div class="table-responsive">
                <table class="table table-bordered table-striped bg-white">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Image</th>
                            <th>Name</th>
                            <th>Price</th>
                            <th>Stock</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($products as $product): ?>
                        <tr>
                            <td><?= $product->id; ?></td>
                            <td>
                                <?php if($product->image): ?>
                                    <img src="<?= base_url('assets/uploads/products/' . $product->image); ?>" width="50" alt="<?= $product->name; ?>">
                                <?php else: ?>
                                    No Image
                                <?php endif; ?>
                            </td>
                            <td><?= $product->name; ?></td>
                            <td>Rp <?= number_format($product->price, 0, ',', '.'); ?></td>
                            <td><?= $product->stock; ?></td>
                            <td>
                                <a href="<?= base_url('admin/edit_product/'.$product->id); ?>" class="btn btn-sm btn-warning">Edit</a>
                                <a href="<?= base_url('admin/delete_product/'.$product->id); ?>" class="btn btn-sm btn-danger" onclick="return confirm('Are you sure?');">Delete</a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </main>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
