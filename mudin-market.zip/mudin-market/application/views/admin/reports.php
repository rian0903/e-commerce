<?php $this->load->view('templates/header'); ?>

<div class="container-fluid">
    <div class="row">
        <!-- Sidebar -->
        <?php $this->load->view('templates/admin_sidebar'); ?>

        <!-- Main Content -->
        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 content-wrapper">
            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                <h1 class="h2">Sales Reports</h1>
                <div class="btn-toolbar mb-2 mb-md-0">
                    <div class="btn-group me-2">
                        <a href="<?= base_url('admin/export_excel'); ?>" class="btn btn-sm btn-outline-success">
                            <i class="fas fa-file-excel"></i> Export Excel
                        </a>
                        <a href="<?= base_url('admin/export_pdf'); ?>" class="btn btn-sm btn-outline-danger">
                            <i class="fas fa-file-pdf"></i> Export PDF
                        </a>
                    </div>
                </div>
            </div>
            
            <div class="row mt-4">
                <div class="col-md-6 mb-4">
                    <div class="card shadow-sm h-100">
                        <div class="card-header bg-white font-weight-bold">Orders by Status</div>
                        <div class="card-body">
                            <table class="table">
                                <thead><tr><th>Status</th><th>Count</th><th>Total Value</th></tr></thead>
                                <tbody>
                                    <?php foreach($status_counts as $row): ?>
                                    <tr>
                                        <td><?= ucfirst($row->status); ?></td>
                                        <td><?= $row->count; ?></td>
                                        <td>Rp <?= number_format($row->total, 0, ',', '.'); ?></td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 mb-4">
                    <div class="card shadow-sm h-100">
                        <div class="card-header bg-white font-weight-bold">Monthly Revenue</div>
                        <div class="card-body">
                            <table class="table">
                                <thead><tr><th>Month</th><th>Revenue</th></tr></thead>
                                <tbody>
                                    <?php foreach($monthly_sales as $row): ?>
                                    <tr>
                                        <td><?= $row->month; ?></td>
                                        <td>Rp <?= number_format($row->total, 0, ',', '.'); ?></td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
