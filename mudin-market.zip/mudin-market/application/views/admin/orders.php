<?php $this->load->view('templates/header'); ?>

<div class="container-fluid">
    <div class="row">
        <!-- Sidebar -->
        <?php $this->load->view('templates/admin_sidebar'); ?>

        <!-- Main Content -->
        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 content-wrapper">
            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                <h1 class="h2">Orders</h1>
            </div>

            <?php if($this->session->flashdata('success')): ?>
                <div class="alert alert-success"><?= $this->session->flashdata('success'); ?></div>
            <?php endif; ?>

            <div class="table-responsive">
                <table class="table table-bordered table-hover bg-white">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Customer</th>
                            <th>Date</th>
                            <th>Total</th>
                            <th>Info</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($orders as $order): ?>
                        <tr>
                            <td>#<?= $order->id; ?></td>
                            <td><?= $order->customer_name; ?></td>
                            <td><?= date('d M Y H:i', strtotime($order->created_at)); ?></td>
                            <td>Rp <?= number_format($order->total_amount, 0, ',', '.'); ?></td>
                            <td>Rp <?= number_format($order->total_amount, 0, ',', '.'); ?></td>
                            <td>
                                <small>
                                    <strong>Pay:</strong> <?= isset($order->payment_method) ? ucwords(str_replace('_', ' ', $order->payment_method)) : '-'; ?><br>
                                    <strong>Ship:</strong> <?= isset($order->shipping_courier) ? $order->shipping_courier : '-'; ?><br>
                                    <strong>Addr:</strong> <?= isset($order->address) ? character_limiter($order->address, 20) : '-'; ?>
                                </small>
                            </td>
                            <td>
                                <span class="badge bg-secondary"><?= $order->status; ?></span>
                            </td>
                            <td>
                                <div class="dropdown">
                                  <button class="btn btn-sm btn-outline-primary dropdown-toggle" type="button" data-bs-toggle="dropdown" data-bs-boundary="viewport">
                                    Change Status
                                  </button>
                                  <ul class="dropdown-menu">
                                    <li><button class="dropdown-item" onclick="openLocationModal(<?= $order->id; ?>)">Update Location</button></li>
                                    <li><hr class="dropdown-divider"></li>
                                    <li><a class="dropdown-item" href="<?= base_url('admin/update_order_status/'.$order->id.'/confirmed'); ?>">Confirm</a></li>
                                    <li><a class="dropdown-item" href="<?= base_url('admin/update_order_status/'.$order->id.'/shipped'); ?>">Shipped</a></li>
                                    <li><a class="dropdown-item" href="<?= base_url('admin/update_order_status/'.$order->id.'/completed'); ?>">Completed</a></li>
                                    <li><hr class="dropdown-divider"></li>
                                    <li><a class="dropdown-item text-danger" href="<?= base_url('admin/update_order_status/'.$order->id.'/cancelled'); ?>">Cancel</a></li>
                                  </ul>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </main>
        </main>
    </div>
</div>

<!-- Location Modal -->
<div class="modal fade" id="locationModal" tabindex="-1">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Update Package Location</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <?= form_open('admin/update_location'); ?>
      <div class="modal-body">
         <input type="hidden" name="order_id" id="modal_order_id">
         <div class="mb-3">
             <label>Latitude</label>
             <input type="text" name="latitude" class="form-control" required>
         </div>
         <div class="mb-3">
             <label>Longitude</label>
             <input type="text" name="longitude" class="form-control" required>
         </div>
         <small class="text-muted">Tip: Use a map tool to get coordinates.</small>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary">Save Location</button>
      </div>
      <?= form_close(); ?>
    </div>
  </div>
</div>

<script>
function openLocationModal(id) {
    document.getElementById('modal_order_id').value = id;
    var myModal = new bootstrap.Modal(document.getElementById('locationModal'));
    myModal.show();
}
</script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
