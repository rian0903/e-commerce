<!DOCTYPE html>
<html>
<head>
    <title>Sales Report</title>
    <style>
        body { font-family: sans-serif; }
        table { width: 100%; border-collapse: collapse; margin-bottom: 20px; }
        th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
        th { background-color: #f2f2f2; }
        h2 { margin-top: 0; }
        .header { text-align: center; margin-bottom: 30px; }
    </style>
</head>
<body>
    <div class="header">
        <h1>Sales Report</h1>
        <p>Generated on: <?= date('d M Y H:i'); ?></p>
    </div>

    <h2>Orders by Status</h2>
    <table>
        <thead>
            <tr>
                <th>Status</th>
                <th>Count</th>
                <th>Total Value</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach($status_counts as $row): ?>
            <tr>
                <td><?= ucfirst($row->status); ?></td>
                <td><?= $row->count; ?></td>
                <td>Rp <?= number_format($row->total, 0, ',', '.'); ?></td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>

    <h2>Monthly Revenue</h2>
    <table>
        <thead>
            <tr>
                <th>Month</th>
                <th>Revenue</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach($monthly_sales as $row): ?>
            <tr>
                <td><?= $row->month; ?></td>
                <td>Rp <?= number_format($row->total, 0, ',', '.'); ?></td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</body>
</html>
