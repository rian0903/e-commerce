<?php $this->load->view('templates/header'); ?>

<div class="container-fluid">
    <div class="row">
        <!-- Sidebar -->
        <?php $this->load->view('templates/admin_sidebar'); ?>

        <!-- Main Content -->
        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 content-wrapper">
            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                <h1 class="h2"><?= isset($product) ? 'Edit Product' : 'Add New Product'; ?></h1>
            </div>

            <?php if($this->session->flashdata('error')): ?>
                <div class="alert alert-danger"><?= $this->session->flashdata('error'); ?></div>
            <?php endif; ?>

            <div class="card shadow-sm">
                <div class="card-body">
                    <?= form_open_multipart(isset($product) ? 'admin/edit_product/'.$product->id : 'admin/add_product'); ?>
                        <div class="mb-3">
                            <label for="name" class="form-label">Product Name</label>
                            <input type="text" class="form-control" id="name" name="name" value="<?= set_value('name', isset($product) ? $product->name : ''); ?>" required>
                            <small class="text-danger"><?= form_error('name'); ?></small>
                        </div>
                        <div class="mb-3">
                            <label for="description" class="form-label">Description</label>
                            <textarea class="form-control" id="description" name="description" rows="3"><?= set_value('description', isset($product) ? $product->description : ''); ?></textarea>
                        </div>
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="price" class="form-label">Price</label>
                                <input type="number" class="form-control" id="price" name="price" value="<?= set_value('price', isset($product) ? $product->price : ''); ?>" required>
                                <small class="text-danger"><?= form_error('price'); ?></small>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="stock" class="form-label">Stock</label>
                                <input type="number" class="form-control" id="stock" name="stock" value="<?= set_value('stock', isset($product) ? $product->stock : ''); ?>" required>
                                <small class="text-danger"><?= form_error('stock'); ?></small>
                            </div>
                        </div>
                        <div class="mb-3">
                            <label for="image" class="form-label">Product Image</label>
                            <input type="file" class="form-control" id="image" name="image">
                            <?php if(isset($product) && $product->image): ?>
                                <div class="mt-2">
                                    <img src="<?= base_url('assets/uploads/products/' . $product->image); ?>" width="100">
                                    <p class="text-muted">Current Image</p>
                                </div>
                            <?php endif; ?>
                        </div>
                        
                        <div class="d-flex justify-content-between">
                            <a href="<?= base_url('admin/products'); ?>" class="btn btn-secondary">Cancel</a>
                            <button type="submit" class="btn btn-success">Save Product</button>
                        </div>
                    <?= form_close(); ?>
                </div>
            </div>
        </main>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
