<?php $this->load->view('templates/header'); ?>

<!-- Hero Section -->
<div class="banner_section">
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <h1 class="banner_taital">Get Start <br><span class="banner_text">Your favorite shopping</span></h1>
                <div class="read_bt"><a href="#">Buy Now</a></div>
            </div>
            <div class="col-md-6">
                 <!-- Placeholder for Hero Image -->
                 <div class="text-center">
                    <img src="https://themewagon.github.io/eflyer/images/banner-img.png" class="img-fluid" alt="Banner" style="max-height: 400px;">
                    <!-- Fallback if internet not available, user can replace -->
                 </div>
            </div>
        </div>
    </div>
</div>

<!-- Product Section -->
<div class="fashion_section">
    <div class="container">
        <h1 class="fashion_taital">our products</h1>
        <div class="row mt-5">
            <?php if(!empty($products)): ?>
                <?php foreach($products as $product): ?>
                <div class="col-lg-4 col-sm-6">
                    <div class="box_main">
                        <h4 class="shirt_text"><?= $product->name; ?></h4>
                        <p class="price_text">Start Price  <span style="color: #262626;">Rp <?= number_format($product->price, 0, ',', '.'); ?></span></p>
                        <div class="tshirt_img">
                             <?php if($product->image): ?>
                                <img src="<?= base_url('assets/uploads/products/' . $product->image); ?>" alt="<?= $product->name; ?>" style="max-width:100%; max-height:100%;">
                            <?php else: ?>
                                <div class="d-flex align-items-center justify-content-center h-100 bg-light text-muted">No Image</div>
                            <?php endif; ?>
                        </div>
                        <div class="btn_main">
                            <div class="buy_bt">
                                <?php if($product->stock > 0): ?>
                                    <a href="<?= base_url('user/add_to_cart/'.$product->id); ?>">Add To Cart</a>
                                <?php else: ?>
                                    <a href="#" class="text-muted">Out Of Stock</a>
                                <?php endif; ?>
                            </div>
                            <div class="seemore_bt"><a href="<?= base_url('home/detail/'.$product->id); ?>">See More</a></div>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            <?php else: ?>
                <div class="col-12 text-center">
                    <p>No products found.</p>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php $this->load->view('templates/footer'); ?>
