<?php $this->load->view('templates/header'); ?>

<div class="container py-5">
    <div class="row">
        <!-- Breadcrumbs -->
        <div class="col-12 mb-4">
             <nav aria-label="breadcrumb">
              <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?= base_url(); ?>">Home</a></li>
                <li class="breadcrumb-item active" aria-current="page"><?= $product->name; ?></li>
              </ol>
            </nav>
        </div>

        <!-- Product Image -->
        <div class="col-md-6 mb-4">
            <div class="card border-0 shadow-sm">
                <?php if($product->image): ?>
                    <img src="<?= base_url('assets/uploads/products/' . $product->image); ?>" class="card-img-top img-fluid" alt="<?= $product->name; ?>" style="object-fit: cover; height: 500px;">
                <?php else: ?>
                    <div class="d-flex align-items-center justify-content-center bg-light text-muted" style="height: 500px;">
                        <i class="fas fa-image fa-3x"></i>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- Product Details -->
        <div class="col-md-6">
            <h1 class="fw-bold mb-3"><?= $product->name; ?></h1>
            <h2 class="text-success mb-3">Rp <?= number_format($product->price, 0, ',', '.'); ?></h2>
            
            <div class="mb-4">
                <h5 class="fw-bold">Description:</h5>
                <p class="text-muted" style="white-space: pre-line;"><?= $product->description ?: 'No description available.'; ?></p>
            </div>

            <div class="mb-4">
                <h5 class="fw-bold">Availability:</h5>
                <?php if($product->stock > 0): ?>
                    <span class="badge bg-success">In Stock (<?= $product->stock; ?> items)</span>
                <?php else: ?>
                    <span class="badge bg-danger">Out of Stock</span>
                <?php endif; ?>
            </div>

            <div class="d-grid gap-2">
                <?php if($product->stock > 0): ?>
                    <a href="<?= base_url('user/add_to_cart/'.$product->id); ?>" class="btn btn-warning btn-lg text-white fw-bold">
                        <i class="fas fa-shopping-cart me-2"></i> Add to Cart
                    </a>
                <?php else: ?>
                     <button class="btn btn-secondary btn-lg" disabled>Out of Stock</button>
                <?php endif; ?>
                <a href="https://wa.me/?text=Check%20out%20this%20product:%20<?= current_url(); ?>" target="_blank" class="btn btn-outline-success">
                    <i class="fab fa-whatsapp me-2"></i> Share to WhatsApp
                </a>
            </div>
        </div>
    </div>
</div>

<?php $this->load->view('templates/footer'); ?>
