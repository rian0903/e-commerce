<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Product_model extends CI_Model {

    public function __construct() {
        parent::__construct();
        $this->load->database();
    }

    public function get_all_products() {
        return $this->db->get('products')->result();
    }

    public function get_product($id) {
        $this->db->where('id', $id);
        return $this->db->get('products')->row();
    }

    public function insert_product($data) {
        return $this->db->insert('products', $data);
    }

    public function update_product($id, $data) {
        $this->db->where('id', $id);
        return $this->db->update('products', $data);
    }

    public function delete_product($id) {
        $this->db->where('id', $id);
        return $this->db->delete('products');
    }

    public function reduce_stock($id, $qty) {
        $this->db->set('stock', 'stock - ' . (int) $qty, FALSE);
        $this->db->where('id', $id);
        $this->db->where('stock >=', $qty); // Prevent negative stock
        return $this->db->update('products');
    }
}
